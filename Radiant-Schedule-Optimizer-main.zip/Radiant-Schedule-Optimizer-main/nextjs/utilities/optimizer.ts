export default class Optimizer {
	private models: any[];

	constructor(models: any[]) {
		this.models = models;
	}
}
